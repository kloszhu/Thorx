﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson.Serialization.IdGenerators;
namespace Thorx.MongoToolkit
{
    public class EntityGuidID<T> : IEntity<string>
    {
        [BsonElement("_id")]
        public string Id { get; set; }

        public void Create()
        {
            this.Id = Guid.NewGuid().ToString();
        }

        public void Update(string UpdateId)
        {
            this.Id = UpdateId;
        }
    }
}
